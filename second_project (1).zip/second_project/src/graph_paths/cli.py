"""Simple CLI demo for shortest path algorithms."""

from __future__ import annotations

from math import dist
import argparse

from .algorithms import WeightedGraph, a_star_shortest_path

Coordinate = tuple[int, int]


def euclidean_heuristic(a: Coordinate, b: Coordinate) -> float:
    return dist(a, b)


def build_demo_graph() -> WeightedGraph[Coordinate]:
    graph: WeightedGraph[Coordinate] = WeightedGraph()
    edges = [
        ((0, 0), (1, 0), 1),
        ((1, 0), (2, 0), 1),
        ((0, 0), (0, 1), 1),
        ((0, 1), (1, 1), 1),
        ((1, 1), (2, 1), 1),
        ((2, 0), (2, 1), 1),
        ((2, 1), (3, 1), 1),
        ((1, 1), (1, 2), 1),
        ((1, 2), (2, 2), 1),
        ((2, 2), (3, 1), 1.5),
    ]
    for source, target, weight in edges:
        graph.add_edge(source, target, weight)
        graph.add_edge(target, source, weight)
    return graph


def main() -> None:
    parser = argparse.ArgumentParser(description="Run A* on a demo graph.")
    parser.add_argument("start_x", type=int)
    parser.add_argument("start_y", type=int)
    parser.add_argument("goal_x", type=int)
    parser.add_argument("goal_y", type=int)
    args = parser.parse_args()

    graph = build_demo_graph()
    start = (args.start_x, args.start_y)
    goal = (args.goal_x, args.goal_y)
    cost, path = a_star_shortest_path(graph, start, goal, euclidean_heuristic)

    print(f"Cost: {cost}")
    print("Path:", " -> ".join(map(str, path)))


if __name__ == "__main__":
    main()
