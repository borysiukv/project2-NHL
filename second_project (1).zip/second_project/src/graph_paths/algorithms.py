"""Shortest path algorithms implemented in a clean, Pythonic style.

This module provides:
- a light-weight weighted graph abstraction;
- Dijkstra's algorithm for single-source shortest paths;
- A* search for shortest path discovery with admissible heuristics.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import heapq
from math import inf
from typing import Callable, Dict, Generic, Hashable, Iterable, Iterator, List, Tuple, TypeVar

Node = TypeVar("Node", bound=Hashable)
Weight = float
Heuristic = Callable[[Node, Node], float]


@dataclass(slots=True)
class WeightedGraph(Generic[Node]):
    """Directed weighted graph represented with adjacency lists.

    The graph accepts any hashable node type and stores outgoing edges in a
    dictionary mapping each node to a list of ``(neighbor, weight)`` tuples.
    """

    adjacency: Dict[Node, List[Tuple[Node, Weight]]] = field(default_factory=dict)

    def add_edge(self, source: Node, target: Node, weight: Weight, /) -> None:
        """Add a directed edge to the graph.

        Args:
            source: Starting node.
            target: Destination node.
            weight: Non-negative edge cost.

        Raises:
            ValueError: If ``weight`` is negative.
        """
        if weight < 0:
            raise ValueError("Dijkstra and A* require non-negative edge weights.")

        self.adjacency.setdefault(source, []).append((target, weight))
        self.adjacency.setdefault(target, [])

    def neighbors(self, node: Node) -> Iterable[Tuple[Node, Weight]]:
        """Return outgoing neighbors for ``node``."""
        return self.adjacency.get(node, ())

    def nodes(self) -> Iterator[Node]:
        """Iterate over all nodes in the graph."""
        return iter(self.adjacency)


@dataclass(slots=True)
class _PriorityEntry(Generic[Node]):
    priority: float
    node: Node

    def __lt__(self, other: "_PriorityEntry[Node]") -> bool:
        return self.priority < other.priority


def dijkstra_shortest_paths(
    graph: WeightedGraph[Node],
    source: Node,
) -> Tuple[Dict[Node, Weight], Dict[Node, Node | None]]:
    """Compute shortest-path distances from ``source`` using Dijkstra.

    Args:
        graph: Weighted directed graph with non-negative edge costs.
        source: Starting node.

    Returns:
        A pair ``(distances, predecessors)`` where:
        - ``distances[node]`` is the minimum cost from ``source`` to ``node``;
        - ``predecessors[node]`` stores the previous node on a shortest path.
    """
    distances: Dict[Node, Weight] = {node: inf for node in graph.nodes()}
    predecessors: Dict[Node, Node | None] = {node: None for node in graph.nodes()}

    if source not in distances:
        distances[source] = 0.0
        predecessors[source] = None
    else:
        distances[source] = 0.0

    queue: List[_PriorityEntry[Node]] = [_PriorityEntry(0.0, source)]

    while queue:
        current = heapq.heappop(queue)
        current_distance = distances[current.node]

        if current.priority > current_distance:
            continue

        for neighbor, weight in graph.neighbors(current.node):
            candidate = current_distance + weight
            if candidate < distances[neighbor]:
                distances[neighbor] = candidate
                predecessors[neighbor] = current.node
                heapq.heappush(queue, _PriorityEntry(candidate, neighbor))

    return distances, predecessors


def a_star_shortest_path(
    graph: WeightedGraph[Node],
    start: Node,
    goal: Node,
    heuristic: Heuristic[Node],
) -> Tuple[Weight, List[Node]]:
    """Find a shortest path between ``start`` and ``goal`` using A*.

    Args:
        graph: Weighted directed graph.
        start: Start node.
        goal: Goal node.
        heuristic: Estimated remaining distance from any node to the goal.

    Returns:
        A pair ``(cost, path)``.

    Raises:
        ValueError: If no path exists between ``start`` and ``goal``.
    """
    frontier: List[_PriorityEntry[Node]] = [_PriorityEntry(heuristic(start, goal), start)]
    g_score: Dict[Node, Weight] = {start: 0.0}
    predecessor: Dict[Node, Node | None] = {start: None}

    while frontier:
        current = heapq.heappop(frontier).node
        if current == goal:
            return g_score[goal], _reconstruct_path(predecessor, goal)

        for neighbor, weight in graph.neighbors(current):
            tentative_score = g_score[current] + weight
            if tentative_score < g_score.get(neighbor, inf):
                g_score[neighbor] = tentative_score
                predecessor[neighbor] = current
                priority = tentative_score + heuristic(neighbor, goal)
                heapq.heappush(frontier, _PriorityEntry(priority, neighbor))

    raise ValueError(f"No path found from {start!r} to {goal!r}.")


def _reconstruct_path(predecessor: Dict[Node, Node | None], goal: Node) -> List[Node]:
    path: List[Node] = [goal]
    current = goal
    while predecessor[current] is not None:
        current = predecessor[current]  # type: ignore[assignment]
        path.append(current)
    path.reverse()
    return path
